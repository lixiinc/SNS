from django.test import TestCase
from .model_factories import *
from ..models import *

#test UserProfile model
class UserProfileModelTest(TestCase):
    appuser = None

    def setUp(self):
        self.sppuser = UserProfileFactory.create()

    def tearDown(self):
        User.objects.all().delete()
        UserProfile.objects.all().delete()
        Post.objects.all().delete()
        Comment.objects.all().delete()
        UserFactory.reset_sequence()
        UserProfileFactory.reset_sequence()
        PostFactory.reset_sequence()
        CommentFactory.reset_sequence()

    def create_UserProfile(self, bio="hello world", birthdate='1997-08-10', location='Singapore', profileImage='123.png'):
        user = User.objects.create(username='user_a')
        return UserProfile.objects.create(user=user, bio=bio, birthdate=birthdate, location=location, profileImage=profileImage)

    def test_UserProfileModelCreation(self):
        #test objects creation of Model
        UserProfileModel = self.create_UserProfile()
        self.assertTrue(UserProfileModel, UserProfile)

    def test_bioFieldMaxLength(self):
        #test max_length of 'bio' field
        user = UserProfile.objects.get(id=1)
        max_length = user._meta.get_field('bio').max_length
        self.assertEqual(max_length, 400)


#test post model 
class PostModelTest(TestCase):
    post = None

    def setUp(self):
        self.post = PostFactory.create()

    def tearDown(self):
        User.objects.all().delete()
        UserProfile.objects.all().delete()
        Post.objects.all().delete()
        Comment.objects.all().delete()
        UserFactory.reset_sequence()
        UserProfileFactory.reset_sequence()
        PostFactory.reset_sequence()
        CommentFactory.reset_sequence()

    def createPost(self, body="hello world", image ='xyz.png', created_date="2023-03-13", shared_on="2023-03-13", author='factory'):
        user = User.objects.create(username="user_a")
        return Post.objects.create(user=user, body=body, image=image, created_date=created_date, shared_on=shared_on, author=author)

    def test_postModelCreation(self):
        #test objects creation of Model
        post_objects = self.createPost()
        self.assertTrue(isinstance(post_objects, Post))

    def test_testFieldMaxLength(self):
        #test max_length of 'text' field
        post = Post.objects.get()
        max_length = post._meta.get_field('text').max_length
        self.assertEqual(max_length, 500)

