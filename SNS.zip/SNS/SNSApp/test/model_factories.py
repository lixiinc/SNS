import factory
from django.test import TestCase
from django.conf import settings
from django.core.files import File
from ..models import *
from random import randint,choice

class UserFactory(factory.django.DjangoModelFactory):
    username = 'factory'
    email = 'test@factory.com'
    password = '123'

    class Meta:
        model = User

class UserProfileFactory(factory.django.DjangoModelFactory):
    user = factory.SubFactory(UserFactory)
    bio = "hello world, It's django"
    birthdate = "1996-08-06"
    location = "Singapore"
    profileImage = "./media/default.png"
    
    class Meta:
        model = UserProfile

class PostFactory(factory.django.DjangoModelFactory):
    body = "Hello World"
    image = "./media/default.png"
    created_date = "2023-03-13"
    shared_on = "2023-03-13"
    author = "Factory"   

    class Meta:
        model = Post

class CommentFactory(factory.django.DjangoModelFactory):
    comment = "Nice"
    created_date = "2023-03-13"
    author = "Factoryboy"

    class Meta:
        model = Comment